const { EmbedBuilder, WebhookClient } = require('discord.js');
const ms = require('ms');

module.exports = {
  name: 'primeadd',
  aliases: ['padd'],
  description: 'Adds a user to the prime database',
  category: 'developer',
  args: true,
  usage: 'primeadd <user> <base/basenp/duration> <server_count>',
  userPerms: [],
  botPerms: [],
  owner: true,

  execute: async (client, message, args) => {
    let access = ["903964729691762689"];

    client.owners.forEach((x) => access.push(x));

    if (!access.includes(message.author.id)) return message.reply("❌ You do not have permission to use this command.");

    // Get user ID from mention or argument
    let userId = message.mentions.users.first()?.id || args[0]?.replace(/[^0-9]/g, '');

    if (!userId) return message.reply("❌ Please mention a user or provide their ID.");

    let user;
    try {
      user = await client.users.fetch(userId);
    } catch (err) {
      return message.reply("❌ Invalid user ID.");
    }

    let type = args[1]?.toLowerCase();
    let validTypes = ["base", "basenp", "duration"];

    if (!validTypes.includes(type)) {
      return message.reply("❌ Invalid type! Choose from `base`, `basenp`, or `duration`.");
    }

    let serverCount = parseInt(args[2]);
    if (isNaN(serverCount) || serverCount <= 0) {
      return message.reply("❌ Please enter a valid server count.");
    }

    // Set prime in database
    let primeData = {
      type: type,
      servers: serverCount,
      addedBy: message.author.id,
      timestamp: Date.now()
    };

    if (type === "duration") {
      let duration = args[3];
      if (!duration || isNaN(ms(duration))) {
        return message.reply("❌ Please provide a valid duration (e.g., `10d`, `1w`).");
      }
      primeData.expiry = Date.now() + ms(duration);
    }

    await client.db.set(`prime_${user.id}`, primeData);

    // Webhook logging
    const webhook = new WebhookClient({ url: client.web_prime });
    webhook.send({
      embeds: [
        new EmbedBuilder()
          .setTitle("Prime Access Added")
          .setDescription(`**User:** ${user.tag} \n**ID:** ${user.id}\n**Type:** ${type} \n**Servers:** ${serverCount}`)
          .setColor("#2f3136")
          .setFooter({ text: `Added by ${message.author.tag}` })
          .setTimestamp()
      ]
    });

    return message.reply({
      embeds: [
        new EmbedBuilder()
          .setDescription(`✅ **Added** \`${user.tag}\` as a prime user!\n**Type:** ${type}\n**Servers:** ${serverCount}`)
          .setColor("#2f3136")
      ]
    });
  }
};