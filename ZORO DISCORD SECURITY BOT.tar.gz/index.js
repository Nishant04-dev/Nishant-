/** @format */
console.log(`
VENGEANCE SERVICES BY NISHANT CHAUHAN`);

const { ZORO } = require('./src/client');
const client = new ZORO();
client.connect();
module.exports = client;
console.log(`Made By NISHANT`)
