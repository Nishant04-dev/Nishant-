# Security Bot

# Installation

- To clone this repo
```

git clone https://github.com/RayDev07/Security-Bot.git

cd Security-Bot

```

- To install modules
```

npm i

```

- To run the bot
```

node sharder.js

```
